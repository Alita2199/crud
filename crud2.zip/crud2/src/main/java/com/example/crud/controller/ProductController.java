package com.example.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.crud.model.Product;
import com.example.crud.service.ProductService;

@RestController
public class ProductController 
{
	@Autowired
	private ProductService service;
	
	@PostMapping("/saveProduct")
	//@RequestMapping(value="/saveProduct",method=RequestMethod.POST)
	public Product addProduct(@RequestBody Product product)      //@RequestBody annotation is necessary when we are passing or adding model class' object
	{
		return service.saveSingleProduct(product);
	}
	
	
	@PostMapping("/saveMultipleProduct")
	//@RequestMapping(value="/saveMultipleProduct",method=RequestMethod.POST)
	public List<Product> addMultipleProduct(@RequestBody List<Product> products)    //@RequestBody annotation is necessary when we are passing or adding model class' object
	{
		return service.saveMultipleProducts(products); 
	}
	
	
	@GetMapping("/products")
	//@RequestMapping(value="/products",method=RequestMethod.GET)   //The "GET" method is used to fetch a resource from a server. Also the "GET" method is the default method, so if we don't specify this method then no need to worry about it...
	public List<Product> findAllProducts11()
	{
		return service.getProducts();
	}
	
	
	@GetMapping("/productById/{id}")     //There is only one product with the id number because "id number is unique here"
	//@RequestMapping(value="/productById/{id}",method=RequestMethod.GET)
	public Product findProductById(@PathVariable int id)
	{
		return service.getProductById(id);
	}
	
	
	
	@GetMapping("/productByName/{name}")     //Custom Finder method
	//@RequestMapping(value="/productByName/{name}",method=RequestMethod.GET)
	public List<Product> findProductByName(@PathVariable String name)  //There may be multiple products with the same name so I write return type as"List<Product>"   
	{
		return service.getProductByName(name);
	}
	
	
	@GetMapping("/productByLowPrice/{price}")     //Custom Finder method
	//@RequestMapping(value="/productByPrice/{price}",method=RequestMethod.GET)
	public List<Product> findProductByLowPrice(@PathVariable double price)   //There may be multiple products with the same name so I write return type as"List<Product>"
	{
		return service.getProductByLowPrice(price);
	}
	
	
	@GetMapping("/productByHighPrice/{price}")      //Custom Finder method
	//@RequestMapping(value="/productByPrice/{price}",method=RequestMethod.GET)
	public List<Product> findProductByHighPrice(@PathVariable double price)   //There may be multiple products with the same name so I write return type as"List<Product>"
	{
		return service.getProductByHighPrice(price);
	}
	
	
	@GetMapping("/productByPriceAsc")             //Custom Finder method
	//@RequestMapping(value="/productByPriceAsc",method=RequestMethod.GET)
	public List<Product> findProductByPrice11()
	{
		return service.getProductInAscByPrice();
	}
	
	
	@GetMapping("/productByPriceDesc")             //Custom Finder method
	//@RequestMapping(value="/productByPriceDesc",method=RequestMethod.GET)
	public List<Product> findProductByPrice22()
	{
		return service.getProductInDescByPrice();
	}
	
	
	@GetMapping("/nameOfProductBasedOnPriceAsc/{name}")     //Custom Finder method
	//@RequestMapping(value="/nameOfProductBasedOnPriceAsc/{name}",method=RequestMethod.GET)
	public List<Product> findProductByName11(@PathVariable String name)
	{
		return service.getNameBasedOnPriceAsc(name);
	}
	
	
	@GetMapping("/nameOfProductBasedOnPriceDesc/{name}")     //Custom Finder method
	//@RequestMapping(value="/nameOfProductBasedOnPriceDesc{name}",method=RequestMethod.GET)
	public List<Product> findProductByName22(@PathVariable String name)
	{
		return service.getNameBasedOnPriceDesc(name);
	}
	
	
	@GetMapping("/nameOfProductBasedOnPriceAscIdDesc/{name}")      //Custom Finder method
	//@RequestMapping(value="/nameOfProductBasedOnPriceAscIdDesc/{name}",method=RequestMethod.GET)
	public List<Product> findProductByName33(@PathVariable String name)
	{
		return service.getNameBasedOnPriceAscIdDesc(name);
	}
	
	
	@GetMapping("/nameOfProductBasedOnIdDescPriceAsc/{name}")      //Custom Finder method
	//@RequestMapping(value="/nameOfProductBasedOnIdDescPriceAsc/{name}",method=RequestMethod.GET)
	public List<Product> findProductByName44(@PathVariable String name)
	{
		return service.getNameBasedOnIdDescPriceAsc(name);
	}
	
	
	@GetMapping("/IdDesc")       //Custom Finder method
	//@RequestMapping(value="/IdDesc",method=RequestMethod.GET)
	public List<Product> findAllName()
	{
		return service.getAllName();
	}
	
	
	
	@GetMapping("/productsAll")        // @Query annotation, JPQL query
	//@RequestMapping(value="/productsAll",method=RequestMethod.GET)
	public List<Product> findAllProducts22()
	{
		return service.getProducts();
	}
	
	@GetMapping("/prodByName/{name}")     // @Query annotation, JPQL query
	//@RequestMapping(value="/prodByName/{name}",method=RequestMethod.GET)
	public List<Product> findAllProducts33(@PathVariable String name)
	{
		return service.getProductsByName(name);
	}
	
	@GetMapping("/prodByPandQ/{price}/{quantity}")    // @Query annotation, JPQL query
	//@RequestMapping(value="/prodByPandQ/{price}/{quantity}",method=RequestMethod.GET)
	public List<Product> findAllProducts44(@PathVariable double price,@PathVariable int quantity)
	{
		return service.getProductsByPAndQ(price,quantity);
	}
	
	@GetMapping("/prodByPrice/{price}")     // @Query annotation, JPQL query
	//@RequestMapping(value="/prodByPrice/{price}",method=RequestMethod.GET)
	public List<String> findProductsNameByPrice(@PathVariable double price)
	{
		return service.getNameOfProducts(price);
	}
	
	
	@GetMapping("/prodNAndP/{price}")   // @Query annotation, JPQL query
	public List<Double> findProductsNameAndPrice(@PathVariable double price)  //Try List<Object[]>
	{
		return service.getProductsNAndP(price);
	}//It gives an error

	
	
	
	@DeleteMapping("/deleteProduct/{id}")
	//@RequestMapping(value="/deleteProduct/{id}",method=RequestMethod.DELETE)
	public String deleteProduct(@PathVariable int id)
	{
		return service.deleteProduct(id);
	}
	
	
	@PutMapping("/updateProduct")
	//@RequestMapping(value="/updateProduct",method=RequestMethod.PUT)
	public Product updateProduct(@RequestBody Product product)     //@RequestBody annotation is necessary when we are passing or adding model class' object
	{
		return service.updateProduct(product);
	}
}
