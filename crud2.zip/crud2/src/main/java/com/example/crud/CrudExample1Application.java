package com.example.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudExample1Application 
{
	public static void main(String[] args) 
	{
		SpringApplication.run(CrudExample1Application.class, args);
	}
}
