package com.example.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.crud.model.Product;
import com.example.crud.repository.ProductRepository;

@Service
public class ProductService 
{
	@Autowired
	private ProductRepository repo;
	
	public Product saveSingleProduct(Product product)
	{
		return repo.save(product);
	}
	
	public List<Product> saveMultipleProducts(List<Product> products)
	{
		return repo.saveAll(products);
	}
	
	public List<Product> getAllProducts()
	{
		return repo.findAll();
	}
	
	public Product getProductById(int id)
	{
		return repo.findById(id).orElse(null);
	}
	
	
	
	
	public List<Product> getProductByName(String name)  //Custom Finder method
	{
		return repo.findByName(name);
	}
	
	public List<Product> getProductByLowPrice(double price)   //Custom Finder method
	{
		return repo.findByPriceLessThanEqual(price);
	}
	
	public List<Product> getProductByHighPrice(double price)   //Custom Finder method
	{
		return repo.findByPriceGreaterThanEqual(price);
	}
	
	public List<Product> getProductInAscByPrice()   //Custom Finder method
	{
		return repo.findByOrderByPriceAsc();       // findBy-OrderBy-Price-Asc
	}
	
	public List<Product> getProductInDescByPrice()   //Custom Finder method
	{
		return repo.findByOrderByPriceDesc();       // findBy-OrderBy-Price-Desc
	}
	
	public List<Product> getNameBasedOnPriceAsc(String name)     //Custom Finder method
	{
		return repo.findByNameOrderByPriceAsc(name);	  //findBy-Name-OrderBy-Price-Asc (By Default, it is in Ascending order)
	}
	
	public List<Product> getNameBasedOnPriceDesc(String name)     //Custom Finder method
	{
		return repo.findByNameOrderByPriceDesc(name);	  //findBy-Name-OrderBy-Price-Desc
	}
	
	public List<Product> getNameBasedOnPriceAscIdDesc(String name)   //Custom Finder method
	{
		return repo.findByNameOrderByPriceAscIdDesc(name);  //findBy-Name-OrderBy-Price-Asc-Id-Desc
	}
	
	public List<Product> getNameBasedOnIdDescPriceAsc(String name)   //Custom Finder method
	{
		return repo.findByNameOrderByIdDescPriceAsc(name);  //findBy-Name-OrderBy-Id-Desc-Price-Asc
	}
	
	public List<Product> getAllName()    //Custom Finder method
	{
		return repo.findByOrderByIdDesc();     //findBy-OrderBy-Id-Desc
	}
	
	
	
	public List<Product> getProducts()   // @Query annotation, JPQL query
	{
		return repo.getAllProducts();
	}
	
	public List<Product> getProductsByName(String name)    // @Query annotation, JPQL query
	{
		return repo.getProductByName(name);
	}
	
	public List<Product> getProductsByPAndQ(double price,int quantity)  // @Query annotation, JPQL query
	{
		return repo.getProductByPriceAndQuantity(price, quantity);
	}
	
	public List<String> getNameOfProducts(double price)   // @Query annotation, JPQL query
	{
		return repo.getProductsName(price);
	}
	
	public List<Double> getProductsNAndP(double price)   // @Query annotation, JPQL query
	{
		return repo.getProductsNameAndPrice(price);
	}
	
	
	
	public String deleteProduct(int id)
	{
		repo.deleteById(id);
		return "Product of id no "+id+" is deleted successfully....";
	}
	
	public Product updateProduct(Product product)
	{
		Product existingProduct = repo.findById(product.getId()).orElse(null);  //fetch product by getting its id..
		existingProduct.setName(product.getName());
		existingProduct.setQuantity(product.getQuantity());
		existingProduct.setPrice(product.getPrice());
		
		return repo.save(existingProduct);
	}
	
	/*public Product updateProduct(Product product,int id)
	{
		//Product existingProduct = repo.findById(product.getId()).orElse(null);  //fetch product by getting its id..
		product.setName(product.getName());
		product.setQuantity(product.getQuantity());
		product.setPrice(product.getPrice());
		
		return repo.saveOrUpdate();
	}*/
}
