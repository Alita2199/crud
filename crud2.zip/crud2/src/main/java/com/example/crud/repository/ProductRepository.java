package com.example.crud.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.crud.model.Product;

public interface ProductRepository extends JpaRepository<Product,Integer>
{
	public List<Product> findByName(String name);
	
	public List<Product> findByPriceLessThanEqual(double price);
	
	public List<Product> findByPriceGreaterThanEqual(double price);
	
	public List<Product> findByOrderByPriceAsc();    // findBy-OrderBy-Price-Asc
	
	public List<Product> findByOrderByPriceDesc();   // findBy-OrderBy-Price-Desc
	
	public List<Product> findByNameOrderByPriceAsc(String name);   // findBy-Name-OrderBy-Price-Asc (By Default, it is in Ascending order).. Here we have to pass the name in URL 
	
	public List<Product> findByNameOrderByPriceDesc(String name);   // findBy-Name-OrderBy-Price-Desc    Here we have to pass the product name in URL
	
	public List<Product> findByNameOrderByPriceAscIdDesc(String name);   //findBy-Name-OrderBy-Price-Asc-Id-Desc      Here we have to pass the product name in URL
	
	public List<Product> findByNameOrderByIdDescPriceAsc(String name);   //findBy-Name-OrderBy-Id-Desc-Price-Asc      Here we have to pass the product name in URL
	
	public List<Product> findByOrderByIdDesc();     //findBy-OrderBy-Id-Desc
	
	
	@Query("select p from Product p")           //This is JPQL query
	public List<Product> getAllProducts();
	
	@Query("select p from Product p where p.name=:n")  //This is JPQL query  //In this JPQL query, we must have to write the same parameter name ("p.name") as we have already declared in model class
	public List<Product> getProductByName(@Param("n") String name);
	
	@Query("select p from Product p where p.price=:pr and p.quantity=:qt")   //This is JPQL query   //In this JPQL query, we must have to write the same parameter name ("p.price and p.quantity") as we have already declared in model class
	public List<Product> getProductByPriceAndQuantity(@Param("pr") double price, @Param("qt") int quantity);
	
	@Query("select p.name from Product p where p.price=:pr")    //This is JPQL query  //In this JPQL query, we must have to write the same parameter name ("p.name and p.price") as we have already declared in model class
	public List<String> getProductsName(@Param("pr") double price);
	
	@Query("select p.name,p.price from Product p where p.price<=:pr")    //This is JPQL query  //In this JPQL query, we must have to write the same parameter name ("p.name and p.price") as we have already declared in model class
	public List<Double> getProductsNameAndPrice(@Param("pr") double price);
	
	
		
}